package com.ekzamen.ekzamen

data class Contact(
    val id: String,
    val name: String,
    val phoneNumber: String
)