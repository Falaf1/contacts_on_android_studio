package com.ekzamen.ekzamen

import android.content.ContentResolver
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.launch

class ContactsViewModel : ViewModel() {

    private val _allContacts = MutableLiveData<List<Contact>>()
    val allContacts: LiveData<List<Contact>> = _allContacts

    private val _filteredContacts = MutableLiveData<List<Contact>>()
    val filteredContacts: LiveData<List<Contact>> = _filteredContacts

    private var currentFullList: List<Contact> = emptyList()

    fun loadContacts(contentResolver: ContentResolver) {
        viewModelScope.launch {
            val contacts = ContactsHelper.fetchContacts(contentResolver)
            currentFullList = contacts
            _allContacts.value = contacts
            _filteredContacts.value = contacts
        }
    }

    fun filterContacts(query: String?) {
        val searchText = query?.trim()?.lowercase() ?: ""
        if (searchText.isEmpty()) {
            _filteredContacts.value = currentFullList
            return
        }

        val filtered = currentFullList.filter { contact ->
            contact.name.lowercase().contains(searchText) ||
                    contact.phoneNumber.contains(searchText)
        }
        _filteredContacts.value = filtered
    }
}