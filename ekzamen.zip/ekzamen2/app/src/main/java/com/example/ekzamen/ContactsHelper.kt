package com.ekzamen.ekzamen

import android.content.ContentResolver
import android.database.Cursor
import android.provider.ContactsContract
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

object ContactsHelper {

    suspend fun fetchContacts(contentResolver: ContentResolver): List<Contact> =
        withContext(Dispatchers.IO) {
            val contactList = mutableListOf<Contact>()
            var cursor: Cursor? = null

            try {
                val projection = arrayOf(
                    ContactsContract.CommonDataKinds.Phone.CONTACT_ID,
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                    ContactsContract.CommonDataKinds.Phone.NUMBER
                )

                cursor = contentResolver.query(
                    ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                    projection,
                    null,
                    null,
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " ASC"
                )

                cursor?.use {
                    val idColumn = it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.CONTACT_ID)
                    val nameColumn = it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
                    val numberColumn = it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)

                    while (it.moveToNext()) {
                        val id = it.getString(idColumn)
                        val name = it.getString(nameColumn) ?: "Без имени"
                        val phone = it.getString(numberColumn) ?: ""

                        if (phone.isNotBlank()) {
                            val cleanedPhone = phone.replace(" ", "")
                                .replace("-", "")
                                .replace("(", "")
                                .replace(")", "")
                            contactList.add(Contact(id, name, cleanedPhone))
                        }
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            } finally {
                cursor?.close()
            }

            return@withContext contactList.distinctBy { it.id }
        }
}